package com.example.yassirtrendingmovies

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import coil.load
import com.example.yassirtrendingmovies.model.Movie

class MovieDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_details)

        val movieTitle = intent.getStringExtra("MOVIE_TITLE")
        val movieOverview = intent.getStringExtra("MOVIE_OVERVIEW")
        val moviePosterPath = intent.getStringExtra("MOVIE_POSTER_PATH")
        val movieReleaseDate = intent.getStringExtra("MOVIE_RELEASE_DATE")


        if (movieTitle != null && movieOverview != null && moviePosterPath != null && movieReleaseDate != null) {
            findViewById<ImageView>(R.id.imageViewPoster).load("https://image.tmdb.org/t/p/w500$moviePosterPath")
            findViewById<TextView>(R.id.textViewTitle).text = movieTitle
            findViewById<TextView>(R.id.textViewReleaseDate).text = movieReleaseDate
            findViewById<TextView>(R.id.textViewOverview).text = movieOverview
        }

        findViewById<Button>(R.id.buttonBackToMain).setOnClickListener {
            // Finish the current activity (MovieDetailsActivity) and return to MainActivity
            finish()
        }
    }
}