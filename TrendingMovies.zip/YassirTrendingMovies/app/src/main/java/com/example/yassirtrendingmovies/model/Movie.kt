package com.example.yassirtrendingmovies.model

data class Movie(
    val id: Int,
    val title: String,
    val release_date: String,
    val poster_path: String,
    val overview: String
)