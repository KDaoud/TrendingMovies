package com.example.yassirtrendingmovies

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.yassirtrendingmovies.network.RetrofitInstance
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var movieAdapter: MovieAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerViewMovies)
        recyclerView.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            val apiKey = "c9856d0cb57c3f14bf75bdc6c063b8f3"
            try {
                val response = RetrofitInstance.api.getTrendingMovies(apiKey)
                movieAdapter = MovieAdapter(response.results) { movie ->
                    val intent = Intent(this@MainActivity, MovieDetailsActivity::class.java).apply {
                        putExtra("MOVIE_TITLE", movie.title)
                        putExtra("MOVIE_OVERVIEW", movie.overview)
                        putExtra("MOVIE_POSTER_PATH", movie.poster_path)
                        putExtra("MOVIE_RELEASE_DATE", movie.release_date)
                    }
                    startActivity(intent)
                }
                recyclerView.adapter = movieAdapter
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}