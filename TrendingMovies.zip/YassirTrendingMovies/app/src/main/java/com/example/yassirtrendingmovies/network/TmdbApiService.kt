package com.example.yassirtrendingmovies.network

import com.example.yassirtrendingmovies.model.Movie
import retrofit2.http.GET
import retrofit2.http.Query

interface TmdbApiService {
    @GET("trending/movie/week")
    suspend fun getTrendingMovies(@Query("api_key") apiKey: String): TmdbResponse
}

data class TmdbResponse(
    val results: List<Movie>
)